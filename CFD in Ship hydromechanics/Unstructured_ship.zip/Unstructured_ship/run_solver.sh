#!/bin/bash


decomposePar 
mpirun -np 4 renumberMesh -overwrite -parallel 			| tee log.renumberMesh
mpirun -np 4 setFields -parallel 			        | tee log.setFields
mpirun -np 4 checkMesh -parallel 				| tee log.checkMesh
mpirun -np 4 interFoam -parallel 				| tee log.interFoam

#reconstructPar -latestTime

#checkMesh | tee log.checkMesh
#interFoam | tee log.interFoam
